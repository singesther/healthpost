<footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-12" style="text-align: center">
                        Copyright &copy; 2022
                    </div>

                </div>
            </div>
        </footer>
<style>
    .site-footer {
    background: #fafafa;
    border-bottom: 5px solid #e8e9ef;
    width: 100%;
    position: fixed;
    bottom: 0;
    text-align: center;
}

</style>
